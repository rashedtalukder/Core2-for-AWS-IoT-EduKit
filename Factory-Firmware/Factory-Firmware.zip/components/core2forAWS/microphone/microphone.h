#pragma once

void Microphone_Init();
void Microphone_Deinit();
