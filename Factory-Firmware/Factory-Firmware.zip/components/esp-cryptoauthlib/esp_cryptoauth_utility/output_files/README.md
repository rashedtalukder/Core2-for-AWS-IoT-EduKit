# Output Files
After successfull execution of the scripts the certificates or manifest obtained will be stored here.
